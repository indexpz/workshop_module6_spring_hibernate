package pl.indexpz.workshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
